const express = require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');
const cors = require('cors');
const { message } = require('statuses');

const app = express();
const port = 5000;

app.use(express.json()); // This should be present to parse JSON data
app.use(express.urlencoded({ extended: true })); // For form-urlencoded data
app.use(cors());

const mongoURI = 'mongodb://localhost:27017/coderone';
mongoose.connect(mongoURI, { useNewUrlParser: true, useUnifiedTopology: true })
    .then(() => console.log('MongoDB connected'))
    .catch(err => console.error('MongoDB connection error:', err));

//FormData Schema
const formDataSchema = new mongoose.Schema({
    username: String,
    email: String,
    password: String,
    message: String
});

const FormData = mongoose.model('FormData', formDataSchema);

// Handle form submission
app.post('/post', async (req, res) => {
    try {
        const { username, email, password } = req.body;

        if (!username || !email || !password) {
            return res.status(400).json({ message: 'All fields are required.' });
        }

        const formData = new FormData({ username, email, password, message: 'You have successfully signed up!'});
        const savedFormData = await formData.save();

        res.status(200).json({ message: 'User registered successfully', id: savedFormData._id });
    } catch (error) {
        res.status(500).json({ message: 'Server error. Please try again.' });
    }
});

// Endpoint to retrieve a specific message
app.get('/message/:id', async (req, res) => {
    try {
        const messageId = req.params.id;
        const formData = await FormData.findById(messageId);

        if (!formData) {
            return res.status(404).json({ message: 'Message not found' });
        }

        res.status(200).json({
            username: formData.username,
            email: formData.email,
            password: formData.password,
            message: formData.message
        });
    } catch (error) {
        res.status(500).json({ message: 'Error retrieving message' });
    }
});
app.put('/message/:id', async (req, res) => {
    try {
        const messageId = req.params.id;
        const { message } = req.body;

        // Find the message by ID and update it
        const updatedFormData = await FormData.findByIdAndUpdate(messageId, { message }, { new: true });

        if (!updatedFormData) {
            return res.status(404).json({ message: 'Message not found' });
        }

        res.status(200).json({
            username: updatedFormData.username,
            email: updatedFormData.email,
            message: updatedFormData.message
        });
    } catch (error) {
        res.status(500).json({ message: 'Error updating message' });
    }
});
app.listen(port, () => {
    console.log(`Server running at http://localhost:${port}`);
});
